import pyautogui as pya
import time

text = input("enter your message: ") 
number = int(input("enter your number: "))
delay = int(input("enter delay (default: 0.75): "))
count = 0

while True:
    while count < number:
        pya.typewrite(text)
        pya.press("enter") 
        count = count + 1
        time.sleep(delay)